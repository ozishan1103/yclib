# yc-lib

The package grenerates aws credentials using AWS WebIdentity Token and Role.
## To use
`from utils import YcSession`

